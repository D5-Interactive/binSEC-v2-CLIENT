This directory is for a few additional options for YUNG's Better Nether Fortresses.
Options provided may vary by version.
This directory contains subdirectories for supported versions. The first time you run Better Nether Fortresses, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Nether Fortresses for MC 1.21 on Fabric, the 'fabric-26_1' subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support the additional options.
NOTE -- Most of this mod's config settings can be found in a config file outside this folder!
For example, on Fabric 1.21 the file is 'betterfortresses-fabric-26_1.toml'.
Also note that many of the structure's settings such as spawn rate & spawn conditions can only be modified via data pack.